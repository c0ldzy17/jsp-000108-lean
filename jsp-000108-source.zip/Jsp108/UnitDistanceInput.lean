import SawinTotallyRealTowers.SawinTotallyRealTower
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.RingTheory.RamificationInertia.Basic
import Mathlib.RingTheory.Ideal.Int
import Mathlib.RingTheory.DedekindDomain.Ideal.Basic
import Mathlib.Data.Set.Card
import Mathlib.Tactic

open NumberField
open scoped BigOperators

namespace Jsp108

/-- A degree-sized family of maximal ideals above a rational prime forces full splitting. -/
theorem split_of_maximal_family
    (F : Type) [Field F] [NumberField F] (q : ℕ) (hq : q.Prime)
    (factors : Finset (Ideal (𝓞 F)))
    (hcard : factors.card = Module.finrank ℚ F)
    (hfactors : ∀ P ∈ factors, P.IsMaximal ∧ (q : 𝓞 F) ∈ P) :
    (∀ P ∈ (Ideal.span {(q : ℤ)}).primesOver (𝓞 F),
      P.ramificationIdx ℤ = 1 ∧ P.inertiaDeg ℤ = 1) ∧
    ((Ideal.span {(q : ℤ)}).primesOver (𝓞 F)).ncard = Module.finrank ℚ F := by
  classical
  let : Fact q.Prime := ⟨hq⟩
  let p : Ideal ℤ := Ideal.span {(q : ℤ)}
  let : p.IsMaximal := Int.ideal_span_isMaximal_of_prime q
  let : Fintype (p.primesOver (𝓞 F)) := Fintype.ofFinite _
  have hsub : ∀ P ∈ factors, P ∈ p.primesOver (𝓞 F) := by
    intro P hP
    have hmax := (hfactors P hP).1
    refine ⟨hmax.isPrime, (Ideal.liesOver_iff_dvd_map hmax.ne_top).mpr ?_⟩
    rw [Ideal.dvd_iff_le]
    dsimp [p]
    simp only [Ideal.map_span, Set.image_singleton]
    exact Ideal.span_le.mpr (by simpa using (hfactors P hP).2)
  let e : factors ↪ p.primesOver (𝓞 F) :=
    ⟨fun P => ⟨P.1, hsub P.1 P.2⟩, fun x y h => Subtype.ext (congrArg (fun z : p.primesOver (𝓞 F) => z.1) h)⟩
  have hcard_le : Module.finrank ℚ F ≤ Fintype.card (p.primesOver (𝓞 F)) := by
    simpa [hcard] using Fintype.card_le_of_embedding e
  have hsum : (∑ P : p.primesOver (𝓞 F),
      P.1.ramificationIdx ℤ * P.1.inertiaDeg ℤ) = Module.finrank ℚ F := by
    simpa using (Ideal.sum_ramification_inertia_eq_finrank p (𝓞 F)).trans
      (NumberField.RingOfIntegers.rank F)
  have hpos : ∀ P : p.primesOver (𝓞 F),
      1 ≤ P.1.ramificationIdx ℤ * P.1.inertiaDeg ℤ := by
    intro P
    exact Nat.mul_pos (P.1.ramificationIdx_pos ℤ) (P.1.inertiaDeg_pos ℤ)
  have hcard_ge : Fintype.card (p.primesOver (𝓞 F)) ≤ Module.finrank ℚ F := by
    rw [← hsum, Fintype.card_eq_sum_ones]
    exact Finset.sum_le_sum fun P _ => hpos P
  have hc := Nat.le_antisymm hcard_ge hcard_le
  have hall : ∀ P : p.primesOver (𝓞 F),
      P.1.ramificationIdx ℤ * P.1.inertiaDeg ℤ = 1 := by
    have heq : (∑ P : p.primesOver (𝓞 F), (1 : ℕ)) =
        ∑ P : p.primesOver (𝓞 F), P.1.ramificationIdx ℤ * P.1.inertiaDeg ℤ := by
      simpa using hc.trans hsum.symm
    have h := (Finset.sum_eq_sum_iff_of_le (fun P _ => hpos P)).mp heq
    intro P
    exact (h P (Finset.mem_univ P)).symm
  constructor
  · intro P hP
    exact mul_eq_one.mp (hall ⟨P,hP⟩)
  · exact (Set.fintypeCard_eq_ncard (s := p.primesOver (𝓞 F))).symm.trans hc

/-- Compatibility form for the imported unit-distance argument. -/
theorem split_of_maximal_family_primed
    (F : Type) [Field F] [NumberField F] (q : ℕ) (hq : q.Prime)
    (factors : Finset (Ideal (𝓞 F)))
    (hcard : factors.card = Module.finrank ℚ F)
    (hfactors : ∀ P ∈ factors, P.IsMaximal ∧ (q : 𝓞 F) ∈ P) :
    (∀ P ∈ (Ideal.span {(q : ℤ)}).primesOver (𝓞 F),
      (Ideal.span {(q : ℤ)}).ramificationIdx' P = 1 ∧
      (Ideal.span {(q : ℤ)}).inertiaDeg' P = 1) ∧
    ((Ideal.span {(q : ℤ)}).primesOver (𝓞 F)).ncard = Module.finrank ℚ F := by
  obtain ⟨hsplit, hnum⟩ := split_of_maximal_family F q hq factors hcard hfactors
  refine ⟨?_, hnum⟩
  intro P hP
  let : Fact q.Prime := ⟨hq⟩
  let : P.IsPrime := hP.1
  let : P.LiesOver (Ideal.span {(q : ℤ)}) := hP.2
  let : P.IsMaximal := Ideal.isMaximal_of_mem_primesOver hP
  have hq0 : (Ideal.span {(q : ℤ)} : Ideal ℤ) ≠ ⊥ := by
    simpa only [ne_eq, Ideal.span_singleton_eq_bot, Nat.cast_eq_zero] using hq.ne_zero
  rw [Ideal.ramificationIdx'_eq_ramificationIdx _ _ hq0,
    Ideal.inertiaDeg'_eq_inertiaDeg]
  exact hsplit P hP

/-- The unconditional tower input in the precise arithmetic form used downstream. -/
theorem exists_split_tower :
    ∃ (R : ℝ) (Q : Set ℕ), 0 < R ∧ Q.Infinite ∧
      (∀ q ∈ Q, q.Prime ∧ q % 4 = 1) ∧
      ∀ N : ℕ, ∃ (F : Type) (_ : Field F) (_ : CharZero F) (_ : NumberField F)
        (_ : IsTotallyReal F),
        N ≤ Module.finrank ℚ F ∧ NumberField.rootDiscr F ≤ R ∧
        ∀ q ∈ Q,
          (∀ P ∈ (Ideal.span {(q : ℤ)}).primesOver (𝓞 F),
            (Ideal.span {(q : ℤ)}).ramificationIdx' P = 1 ∧
            (Ideal.span {(q : ℤ)}).inertiaDeg' P = 1) ∧
          ((Ideal.span {(q : ℤ)}).primesOver (𝓞 F)).ncard = Module.finrank ℚ F := by
  classical
  obtain ⟨R, Q, hQ, hprimes, hfields⟩ :=
    ClassFieldTower.Sawin.sawin_totally_real_tower
  refine ⟨max R 1, Q, lt_of_lt_of_le zero_lt_one (le_max_right _ _),
    hQ, hprimes, ?_⟩
  intro N
  obtain ⟨F, instF, instC, instN, instT, hdeg, hrd, hsplit⟩ := hfields N
  let : Field F := instF
  let : CharZero F := instC
  let : NumberField F := instN
  let : IsTotallyReal F := instT
  refine ⟨F, instF, instC, instN, instT, hdeg, ?_, ?_⟩
  · have hrd' : NumberField.rootDiscr F ≤ R := by
      simpa only [NumberField.rootDiscr_def, Int.cast_abs, one_div] using hrd
    exact hrd'.trans (le_max_left _ _)
  · intro q hq
    obtain ⟨factors, hcard, hfactors⟩ := hsplit q hq
    exact split_of_maximal_family_primed F q (hprimes q hq).1 factors hcard hfactors

end Jsp108
