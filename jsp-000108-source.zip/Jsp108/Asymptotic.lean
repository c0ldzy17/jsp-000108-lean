import Mathlib

open Filter
open scoped Topology Asymptotics

namespace Jsp108

/-- A fixed positive power in the dense-graph input refutes every eventual
subpolynomial upper bound after passing to an induced core. -/
theorem not_subpolynomial_eventually_of_dense_transfer
    (f : ℕ → ℕ) (δ : ℝ) (hδ : 0 < δ)
    (htransfer : ∀ N : ℕ, ∃ n : ℕ, N ≤ n ∧
      ∀ k : ℕ, 0 < k → (k : ℝ) < (n : ℝ) ^ δ →
        ∃ m : ℕ, k ≤ m ∧ m ≤ n ∧ k ≤ f m) :
    ¬ ∃ o : ℕ → ℝ, o =o[atTop] (1 : ℕ → ℝ) ∧
      ∀ᶠ n : ℕ in atTop, (f n : ℝ) ≤ (n : ℝ) ^ (o n) := by
  rintro ⟨o, ho, hbound⟩
  have hhalf : 0 < δ / 2 := half_pos hδ
  have hozero : Tendsto o atTop (𝓝 0) :=
    (Asymptotics.isLittleO_one_iff ℝ).mp ho
  have hoevent : ∀ᶠ m : ℕ in atTop, o m < δ / 2 :=
    hozero.eventually (gt_mem_nhds hhalf)
  obtain ⟨M, hM⟩ := eventually_atTop.mp (hoevent.and hbound)
  have hpower : Tendsto (fun n : ℕ => (n : ℝ) ^ (δ / 2)) atTop atTop :=
    (tendsto_rpow_atTop hhalf).comp tendsto_natCast_atTop_atTop
  have hlarge : ∀ᶠ n : ℕ in atTop,
      max (M : ℝ) 2 < (n : ℝ) ^ (δ / 2) :=
    hpower.eventually (eventually_gt_atTop _)
  obtain ⟨N, hN⟩ := eventually_atTop.mp hlarge
  obtain ⟨n, hn, hcore⟩ := htransfer N
  let x : ℝ := (n : ℝ) ^ (δ / 2)
  have hxM : (M : ℝ) < x := lt_of_le_of_lt (le_max_left _ _) (hN n hn)
  have hx2 : 2 < x := lt_of_le_of_lt (le_max_right _ _) (hN n hn)
  let k : ℕ := ⌊x⌋₊ + 1
  have hkpos : 0 < k := by dsimp [k]; omega
  have hxk : x < (k : ℝ) := by
    simpa only [k, Nat.cast_add, Nat.cast_one] using Nat.lt_floor_add_one x
  have hkx : (k : ℝ) ≤ x + 1 := by
    have hfloor := Nat.floor_le (by linarith : 0 ≤ x)
    simp only [k, Nat.cast_add, Nat.cast_one]
    linarith
  have hnpos : (0 : ℝ) < n := by
    by_contra h
    have hnzero : n = 0 := by exact_mod_cast (le_antisymm (le_of_not_gt h) (Nat.cast_nonneg n))
    subst n
    norm_num [x, Real.zero_rpow (ne_of_gt hhalf)] at hx2
  have hpow : (n : ℝ) ^ δ = x * x := by
    dsimp [x]
    rw [← Real.rpow_add hnpos]
    congr 1
    ring
  have hkn : (k : ℝ) < (n : ℝ) ^ δ := by
    rw [hpow]
    nlinarith
  obtain ⟨m, hkm, hmn, hkf⟩ := hcore k hkpos hkn
  have hMk : M ≤ k := by exact_mod_cast (le_of_lt (hxM.trans hxk))
  have hMm : M ≤ m := hMk.trans hkm
  obtain ⟨hom, hfm⟩ := hM m hMm
  have hmone : (1 : ℝ) ≤ m := by exact_mod_cast (hkpos.trans_le hkm)
  have hupper : (f m : ℝ) ≤ x := calc
    (f m : ℝ) ≤ (m : ℝ) ^ (o m) := hfm
    _ ≤ (m : ℝ) ^ (δ / 2) := Real.rpow_le_rpow_of_exponent_le hmone hom.le
    _ ≤ (n : ℝ) ^ (δ / 2) :=
      Real.rpow_le_rpow (Nat.cast_nonneg m) (by exact_mod_cast hmn) hhalf.le
    _ = x := rfl
  have hkfReal : (k : ℝ) ≤ (f m : ℝ) := by exact_mod_cast hkf
  exact (not_lt_of_ge (hkfReal.trans hupper)) hxk

/-- The canonical all-cardinalities formulation follows from the stronger
eventual version. -/
theorem not_subpolynomial_of_dense_transfer
    (f : ℕ → ℕ) (δ : ℝ) (hδ : 0 < δ)
    (htransfer : ∀ N : ℕ, ∃ n : ℕ, N ≤ n ∧
      ∀ k : ℕ, 0 < k → (k : ℝ) < (n : ℝ) ^ δ →
        ∃ m : ℕ, k ≤ m ∧ m ≤ n ∧ k ≤ f m) :
    ¬ ∃ o : ℕ → ℝ, o =o[atTop] (1 : ℕ → ℝ) ∧
      ∀ n : ℕ, (f n : ℝ) ≤ (n : ℝ) ^ (o n) := by
  rintro ⟨o, ho, hbound⟩
  exact not_subpolynomial_eventually_of_dense_transfer f δ hδ htransfer
    ⟨o, ho, Eventually.of_forall hbound⟩

#print axioms not_subpolynomial_eventually_of_dense_transfer
#print axioms not_subpolynomial_of_dense_transfer

end Jsp108
