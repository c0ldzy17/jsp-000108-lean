import Jsp108.Geometry
import Jsp108.Reduction
import ErdosUnitDistance.Basic

namespace Jsp108

theorem li_count_eq_unitDist (P : Finset (EuclideanSpace ℝ (Fin 2))) :
    ErdosUnitDistance.ν P = Erdos.unitDist P := by
  classical
  rw [← Erdos92.card_edgeFinset_unitGraph]
  symm
  unfold ErdosUnitDistance.ν
  apply Finset.card_bij (fun e _ => Sym2.map (Subtype.val : P → _) e)
  · intro e he
    induction e using Sym2.inductionOn with
    | hf x y =>
      have hxy : dist (x : EuclideanSpace ℝ (Fin 2)) y = 1 := by
        have hmem := (SimpleGraph.mem_edgeFinset (G := Erdos92.unitGraph P)).mp he
        exact hmem
      have hne : (x : EuclideanSpace ℝ (Fin 2)) ≠ y := by
        intro h
        simp [h] at hxy
      simpa [hne] using (show (x : EuclideanSpace ℝ (Fin 2)) ∈ P ∧
        (y : EuclideanSpace ℝ (Fin 2)) ∈ P ∧
        (x : EuclideanSpace ℝ (Fin 2)) ≠ y ∧
        dist (x : EuclideanSpace ℝ (Fin 2)) y = 1 from
        ⟨x.property, y.property, hne, hxy⟩)
  · intro e he e' he' h
    exact Sym2.map.injective Subtype.val_injective h
  · intro e he
    induction e using Sym2.inductionOn with
    | hf x y =>
      have h : x ∈ P ∧ y ∈ P ∧ x ≠ y ∧ dist x y = 1 := by
        simpa [and_assoc] using he
      refine ⟨s((⟨x,h.1⟩ : P), (⟨y,h.2.1⟩ : P)), ?_, ?_⟩
      · apply (SimpleGraph.mem_edgeFinset (G := Erdos92.unitGraph P)).mpr
        exact h.2.2.2
      · rfl

theorem li_count_attained (n : ℕ) (hn : 0 < ErdosUnitDistance.νn n) :
    ∃ P : Finset (EuclideanSpace ℝ (Fin 2)),
      P.card = n ∧ Erdos.unitDist P = ErdosUnitDistance.νn n := by
  classical
  let S : Set ℕ := {k | ∃ P : Finset ErdosUnitDistance.Point,
    P.card = n ∧ ErdosUnitDistance.ν P = k}
  have hbound : BddAbove S := by
    refine ⟨(n + 1).choose 2, ?_⟩
    rintro k ⟨P, hPn, rfl⟩
    calc
      ErdosUnitDistance.ν P ≤ P.sym2.card := Finset.card_filter_le _ _
      _ = (P.card + 1).choose 2 := Finset.card_sym2 _
      _ = (n + 1).choose 2 := by rw [hPn]
  have hne : S.Nonempty := by
    by_contra h
    have hS : S = ∅ := Set.not_nonempty_iff_eq_empty.mp h
    have hz : ErdosUnitDistance.νn n = 0 := by
      change sSup S = 0
      rw [hS]
      simp
    omega
  have hfin : S.Finite := (Set.finite_Iic hbound.choose).subset hbound.choose_spec
  have hmem : sSup S ∈ S := hne.csSup_mem hfin
  obtain ⟨P, hcard, hν⟩ := hmem
  exact ⟨P, hcard, (li_count_eq_unitDist P).symm.trans hν⟩

/-- Transfer the existing geometric development's supremum-based statement
to actual point sets and a strict fixed-power inequality. -/
theorem polynomial_growth_of_li_main
    (hmain : ErdosUnitDistance.MainTheorem) : PolynomialUnitDistanceGrowth := by
  obtain ⟨δ, hδ, hInfinite⟩ := hmain
  refine ⟨δ / 2, half_pos hδ, ?_⟩
  intro N
  obtain ⟨n, hnmem, hnlarge⟩ := hInfinite.exists_gt (max N 1)
  have hn1 : 1 < n := (le_max_right N 1).trans_lt hnlarge
  have hnN : N ≤ n := ((le_max_left N 1).trans_lt hnlarge).le
  have hnR : (1 : ℝ) < n := by exact_mod_cast hn1
  have hnuR : 0 < (ErdosUnitDistance.νn n : ℝ) :=
    (Real.rpow_pos_of_pos (by linarith : (0 : ℝ) < n) _).trans_le hnmem.2
  have hnu : 0 < ErdosUnitDistance.νn n := by exact_mod_cast hnuR
  obtain ⟨P, hcard, hcount⟩ := li_count_attained n hnu
  refine ⟨P, hcard ▸ hnN, ?_⟩
  rw [hcard, hcount]
  exact (Real.rpow_lt_rpow_of_exponent_lt hnR (by linarith : 1 + δ / 2 < 1 + δ)).trans_le hnmem.2

#print axioms li_count_eq_unitDist
#print axioms li_count_attained
#print axioms polynomial_growth_of_li_main

end Jsp108
