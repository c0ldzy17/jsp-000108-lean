/-
SPDX-License-Identifier: Apache-2.0

Original JSP-000108 additions contributed by c0ldzy17 with OpenAI Codex assistance.
Licensed under the Apache License, Version 2.0; see LICENSE and LICENSE_SCOPE.md.
Third-party source attributions and notices remain in force.
-/
import Jsp108.Geometry
import Jsp108.Asymptotic

open Filter
open scoped Topology

namespace Jsp108

/-- The fixed positive power improvement needed for the original question.
The quantifier over `δ` precedes every cardinality threshold. -/
def PolynomialUnitDistanceGrowth : Prop :=
  ∃ δ : ℝ, 0 < δ ∧ ∀ N : ℕ,
    ∃ P : Finset (EuclideanSpace ℝ (Fin 2)),
      N ≤ P.card ∧ (P.card : ℝ) ^ (1 + δ) < (Erdos.unitDist P : ℝ)

/-- A dense unit-distance configuration supplies the abstract transfer property.
The final pruned point set may have fewer points, but has at least `k` points. -/
theorem dense_transfer_of_polynomial_growth
    (δ : ℝ) (hδ : 0 < δ)
    (hgrowth : ∀ N : ℕ,
      ∃ P : Finset (EuclideanSpace ℝ (Fin 2)),
        N ≤ P.card ∧ (P.card : ℝ) ^ (1 + δ) < (Erdos.unitDist P : ℝ)) :
    ∀ N : ℕ, ∃ n : ℕ, N ≤ n ∧
      ∀ k : ℕ, 0 < k → (k : ℝ) < (n : ℝ) ^ δ →
        ∃ m : ℕ, k ≤ m ∧ m ≤ n ∧ k ≤ Erdos92.f m := by
  intro N
  obtain ⟨P, hP, hedge⟩ := hgrowth (max N 1)
  refine ⟨P.card, (le_max_left N 1).trans hP, ?_⟩
  intro k hk hkpow
  have hn : 0 < P.card := lt_of_lt_of_le Nat.zero_lt_one ((le_max_right N 1).trans hP)
  have hnR : 0 < (P.card : ℝ) := by exact_mod_cast hn
  have hmul := mul_lt_mul_of_pos_right hkpow hnR
  have hpow : (P.card : ℝ) ^ (1 + δ) = (P.card : ℝ) ^ δ * P.card := by
    rw [Real.rpow_add hnR, Real.rpow_one, mul_comm]
  have hkedge : k * P.card < Erdos.unitDist P := by
    exact_mod_cast (hmul.trans (hpow ▸ hedge))
  obtain ⟨A, hAP, hAne, hkmem, hkf⟩ := Erdos92.lower_f_of_unitDist hk hkedge
  exact ⟨A.card, Erdos92.possible_value_le_card hkmem, Finset.card_le_card hAP, hkf⟩

/-- Formal reduction of the complete JSP108 question to a fixed-power
unit-distance construction. This intermediate theorem makes its input explicit. -/
theorem not_subpolynomial_of_unit_distance_growth
    (hgrowth : PolynomialUnitDistanceGrowth) :
    ¬ ∃ o : ℕ → ℝ, o =o[atTop] (1 : ℕ → ℝ) ∧
      ∀ n, (Erdos92.f n : ℝ) ≤ (n : ℝ) ^ (o n) := by
  obtain ⟨δ, hδ, hgrowth⟩ := hgrowth
  exact not_subpolynomial_of_dense_transfer Erdos92.f δ hδ
    (dense_transfer_of_polynomial_growth δ hδ hgrowth)

/-- The same construction also rules out an eventual subpolynomial bound. -/
theorem not_subpolynomial_eventually_of_unit_distance_growth
    (hgrowth : PolynomialUnitDistanceGrowth) :
    ¬ ∃ o : ℕ → ℝ, o =o[atTop] (1 : ℕ → ℝ) ∧
      ∀ᶠ n in atTop, (Erdos92.f n : ℝ) ≤ (n : ℝ) ^ (o n) := by
  obtain ⟨δ, hδ, hgrowth⟩ := hgrowth
  exact not_subpolynomial_eventually_of_dense_transfer Erdos92.f δ hδ
    (dense_transfer_of_polynomial_growth δ hδ hgrowth)

end Jsp108
