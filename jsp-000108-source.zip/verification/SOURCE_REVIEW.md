# Source review of the replacement adapters

Reviewed 2026-09-17 by a separate cooperating agent, before the final package checks.
This is a submitter-side source review, not designated independent verification.

The four canonical definitions `maxEquidistantPointsAt`, `hasMinEquidistantProperty`,
`possible_f_values`, and `f` match the pinned Formal Conjectures definitions after
expanding the plane notation. The public contracts used by `CountTransport`,
`Reduction`, and `Main` are preserved.

The replacement graph argument maximizes an integer edge surplus over finite
vertex subsets and partitions the edge set. The replacement geometry argument
uses a product-map count, a general circle-fiber estimate, and an injective map
from graph neighbors into that circle. This differs from the previous recursive
pruning and subtype-bijection proof bodies. The mathematical reduction remains
credited to the earlier source; this is not a claim of new mathematics or a
legal clean-room implementation.

Neither replacement file introduces `sorry`, `admit`, an axiom declaration,
`native_decide`, `unsafe`, `extern`, or `implemented_by`. Both modules compiled
successfully before their nonsemantic license headers were added. The packaged
build and replay logs provide the final machine checks.
