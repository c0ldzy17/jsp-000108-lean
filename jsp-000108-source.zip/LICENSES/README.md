# License and notice inventory

This inventory does not apply one blanket license to the package.

| Component | Pinned origin and notice |
|---|---|
| Formal Conjectures definitions used by generated Geometry | `google-deepmind/formal-conjectures@40e7c98697de6f66b8cbdbf641749ab39ed9c152`; Copyright 2025 The Formal Conjectures Authors; Apache License, Version 2.0. See `Apache-2.0.txt`. |
| Unit-distance counting code in `Jsp108/Counting.lean` | Copyright (c) 2026 Kim Morrison. All rights reserved. Released under Apache 2.0, as retained in the file header. Exact source: `plby/lean-proofs@8822f7ddef30fadbd92e1c6ab4ed897af356af5e`, `src/latest/ErdosProblems/Erdos90b/External/ErdosUnitDistance/Counting.lean`; see `Apache-2.0.txt`. |
| `vendor/li` | `logical-intelligence/erdos-unit-distance@b6493074dd103ca32ea4f5e9b0bc9cb3a0379f2e`; Apache-2.0; preserved `vendor/li/LICENSE`, upstream README, and source headers. Modifications are listed in `vendor/li/PATCHES.md` and `PORT_CHANGES.json`. |
| `vendor/sawin` | `n-yamaguchi-0729/SawinTotallyRealTowers@3a455e1aa9140dbbe7b7d68f508392a69c86d0f4`; Naganori Yamaguchi, with disclosed Codex assistance; Apache-2.0; preserved `vendor/sawin/LICENSE`, README, and source headers. |
| Generated pruning and additional geometry proofs from plby | `plby/lean-proofs@8822f7ddef30fadbd92e1c6ab4ed897af356af5e`, `src/latest/ErdosProblems/Erdos92.lean`; source credits Codex / GPT-5.6 Sol. An express license grant for these additional proofs has not been established. Their copied bodies are excluded from this archive; reconstruction references the exact upstream file. See `docs/REPRODUCIBLE_PACKAGING.md`. |
| Mathlib and transitive Lake packages | Downloaded at pinned revisions; their own repository notices and licenses apply. They are not bundled here. |

The local integration and proof additions must retain the source-specific attributions above. This staging inventory does not establish publication rights for any material whose license is unresolved, and it does not turn a source-reconstruction recipe into a license grant.
