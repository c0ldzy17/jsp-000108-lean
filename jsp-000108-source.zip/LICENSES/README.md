# License and notice inventory

Original project additions and local modifications are released under
Apache-2.0. See the root [`LICENSE`](../LICENSE) for the exact text and
[`LICENSE_SCOPE.md`](../LICENSE_SCOPE.md) for the boundaries of that grant.
The grant does not replace third-party authorship or source-specific notices.

| Component | Pinned origin and notice |
|---|---|
| Original integration and v1.1 replacement proofs | Contributions by `c0ldzy17` with OpenAI Codex assistance; Apache-2.0, limited to original additions and local modifications as described in `LICENSE_SCOPE.md`. |
| Formal Conjectures definitions and `possible_f_values_BddAbove` in Geometry | `google-deepmind/formal-conjectures@40e7c98697de6f66b8cbdbf641749ab39ed9c152`; Copyright 2025 The Formal Conjectures Authors; Apache License, Version 2.0. Source-specific notices must remain. |
| Unit-distance counting code in `Jsp108/Counting.lean` | Copyright (c) 2026 Kim Morrison. All rights reserved. Released under Apache 2.0, as retained in the file header. Exact source: `plby/lean-proofs@8822f7ddef30fadbd92e1c6ab4ed897af356af5e`, `src/latest/ErdosProblems/Erdos90b/External/ErdosUnitDistance/Counting.lean`. |
| `vendor/li` | `logical-intelligence/erdos-unit-distance@b6493074dd103ca32ea4f5e9b0bc9cb3a0379f2e`; Apache-2.0; preserved `vendor/li/LICENSE`, upstream README, and source headers. Modifications are listed in `vendor/li/PATCHES.md` and `PORT_CHANGES.json`. The reused `prop38_mkAdmissibleDatum` in `TowerBridge.lean` remains upstream work. |
| `vendor/sawin` | `n-yamaguchi-0729/SawinTotallyRealTowers@3a455e1aa9140dbbe7b7d68f508392a69c86d0f4`; Naganori Yamaguchi, with disclosed Codex assistance; Apache-2.0; preserved `vendor/sawin/LICENSE`, README, and source headers. |
| Mathlib, Lean, and transitive Lake packages | Their own repository notices and licenses apply. They are dependencies, not original project additions. |

`Apache-2.0.txt` preserves the complete Apache license text; the root `LICENSE`
contains the same text.

The v1.0 pruning and geometry adapters contained additional plby proof blocks
whose express license grant had not been established. The v1.1 revision
replaces those blocks with new proofs and explicitly licensed Formal
Conjectures content. Historical attribution is retained in
[`docs/ATTRIBUTION.md`](../docs/ATTRIBUTION.md). The current license grant is not
a grant for the old copied blocks or a claim of new underlying mathematics.
