/-
SPDX-License-Identifier: Apache-2.0

Original JSP-000108 additions contributed by c0ldzy17 with OpenAI Codex assistance.
Licensed under the Apache License, Version 2.0; see LICENSE and LICENSE_SCOPE.md.
Third-party source attributions and notices remain in force.
-/
/-
Compare the permitted axioms with Init from the pinned Lean toolchain.
This is a verification driver, not a proof module. It does not replay proofs.
-/
module
import Lean.Environment
import Lean.Util.Path

public section

open Lean

unsafe def checkCanonicalAxioms (moduleName : Name) : IO Unit := do
  let sysroot ← findSysroot
  initSearchPath sysroot
  let fullSearchPath ← searchPathRef.get
  -- Load the reference Init only from the official toolchain, before allowing
  -- the package search path used by the theorem under verification.
  searchPathRef.set [sysroot / "lib" / "lean"]
  try
    withImportModules #[{ module := `Init }] {} fun canonical => do
      searchPathRef.set fullSearchPath
      IO.println s!"Canonical Init: {sysroot / "lib" / "lean" / "Init.olean"}"
      -- Keep both imported environments alive while their expressions are compared.
      withImportModules #[{ module := moduleName }] {} fun actual => do
        for name in #[`propext, `Classical.choice, `Quot.sound] do
          let some reference := canonical.find? name |
            throw <| IO.userError s!"Canonical Init is missing {name}"
          let some candidate := actual.find? name |
            throw <| IO.userError s!"Target module is missing {name}"
          match reference, candidate with
          | .axiomInfo expected, .axiomInfo observed =>
            if expected.type != observed.type || expected.levelParams != observed.levelParams then
              throw <| IO.userError s!"Noncanonical axiom type or universe parameters: {name}"
            IO.println s!"CHECKED {name}: canonical axiom type and universe parameters"
          | _, _ =>
            throw <| IO.userError s!"Expected an axiom declaration in both environments: {name}"
        IO.println s!"PASS: all three permitted axioms in {moduleName} match the pinned toolchain Init."
  finally
    searchPathRef.set fullSearchPath

unsafe def main (args : List String) : IO UInt32 := do
  let [moduleArg] := args |
    throw <| IO.userError "Usage: lake env lean --run scripts/checkCanonicalAxioms.lean MODULE"
  checkCanonicalAxioms moduleArg.toName
  return 0
