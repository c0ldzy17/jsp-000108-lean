#!/usr/bin/env python3
"""Verify the distributed and prepared Lean sources without using the network."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
manifest = json.loads((root / 'SOURCE_MANIFEST.json').read_text())
files = dict(manifest['root_source_sha256'])
for dependency in manifest['dependencies']:
    for path, digest in dependency['source_sha256'].items():
        files[str(Path(dependency['path']) / path)] = digest
recipe = json.loads((root / manifest['generated_sources']['recipe']).read_text())
for entry in recipe['outputs']:
    files[entry['path']] = entry['sha256']
for path, digest in files.items():
    source = root / path
    if not source.is_file():
        raise SystemExit('Missing source: ' + path + '. Run source preparation first.')
    if hashlib.sha256(source.read_bytes()).hexdigest() != digest:
        raise SystemExit('Source hash mismatch: ' + path)
print(f'Verified {len(files)} Lean source hashes.')
