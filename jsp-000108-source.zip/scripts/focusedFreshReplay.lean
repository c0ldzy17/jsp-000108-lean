/-
Focused fresh Lean-kernel replay. This is a verifier driver, not a proof module.
It calls the stock Lean.Environment.Replay implementation without replacing any
kernel operation. It is not an independently implemented external checker.
-/
module
import all Lean.Replay
import Lean.Util.Path

public section

open Lean
open Lean.Environment

/-- Only the roots are selected; Replay recursively visits their dependencies.
The context and `remaining` contain the complete imported constant map, so mutual
inductives, their constructors, and generated recursors remain available. -/
unsafe def focusedFreshReplay (moduleName : Name) (roots : Array Name) : IO Unit := do
  Lean.withImportModules #[{ module := moduleName }] {} fun source => do
    let allConstants := source.constants.map₁
    let mut remaining : NameSet := {}
    for (name, ci) in allConstants.toList do
      if !ci.isUnsafe && !ci.isPartial then
        remaining := remaining.insert name
    let mut selected : NameSet := {}
    for root in roots do
      let some ci := allConstants[root]? |
        throw <| IO.userError s!"Missing requested theorem: {root}"
      match ci with
      | .thmInfo _ => pure ()
      | _ => throw <| IO.userError s!"Requested root is not a theorem: {root}"
      if ci.isUnsafe || ci.isPartial then
        throw <| IO.userError s!"Requested root is unsafe or partial: {root}"
      selected := selected.insert root
    IO.println s!"Loaded {allConstants.size} declarations; replaying dependency closure of {roots}."
    let fresh ← mkEmptyEnvironment 0
    let (_, state) ← StateRefT'.run
        (s := ({ env := fresh.toKernelEnv, remaining } : Replay.State)) do
      ReaderT.run (r := ({ newConstants := allConstants } : Replay.Context)) do
        Replay.replayConstants selected
        Replay.checkPostponedConstructors
        Replay.checkPostponedRecursors
    let mut count := 0
    let mut axiomNames : Array Name := #[]
    for (name, ci) in state.env.constants.toList do
      count := count + 1
      match ci with
      | .axiomInfo _ =>
        if name != `propext && name != `Classical.choice && name != `Quot.sound then
          throw <| IO.userError s!"Disallowed axiom in replayed closure: {name}"
        axiomNames := axiomNames.push name
      | _ => pure ()
    for root in roots do
      let some actual := state.env.find? root |
        throw <| IO.userError s!"Requested theorem absent after replay: {root}"
      let some expected := allConstants[root]? |
        throw <| IO.userError s!"Original requested theorem vanished: {root}"
      if actual.type != expected.type || actual.levelParams != expected.levelParams ||
          actual.value? (allowOpaque := true) != expected.value? (allowOpaque := true) then
        throw <| IO.userError s!"Requested theorem changed during replay: {root}"
      IO.println s!"CHECKED {root}"
    IO.println s!"PASS: {count} declarations replayed into an empty trust-level-0 environment."
    IO.println s!"Replayed axioms: {axiomNames}"
    IO.println "Stock Lean kernel replay; not an independent external kernel implementation."

unsafe def main (args : List String) : IO UInt32 := do
  let moduleArg :: rootArgs := args |
    throw <| IO.userError "Usage: lake env lean --run scripts/focusedFreshReplay.lean MODULE THEOREM..."
  if rootArgs.isEmpty then
    throw <| IO.userError "At least one theorem name is required."
  initSearchPath (← findSysroot)
  focusedFreshReplay moduleArg.toName (rootArgs.toArray.map String.toName)
  return 0
