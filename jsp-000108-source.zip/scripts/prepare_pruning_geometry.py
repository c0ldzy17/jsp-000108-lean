#!/usr/bin/env python3
"""Reconstruct two local adapters from an independently obtained pinned source.

The recipe contains source line references and local additions, not a vendored
copy of the upstream proof. This tool does not grant a license to that proof.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import urllib.request


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    project = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path,
                        help="Use an existing pinned Erdos92.lean instead of downloading it")
    parser.add_argument("--output-dir", type=Path, default=project)
    parser.add_argument("--check", action="store_true",
                        help="Verify existing files without writing them")
    args = parser.parse_args()
    recipe = json.loads((project / "scripts/pruning-geometry-recipe.json").read_text())
    if args.source:
        source = args.source.read_bytes()
    else:
        request = urllib.request.Request(recipe["source"]["url"],
                                         headers={"User-Agent": "JSP108-reproducible-preparation"})
        with urllib.request.urlopen(request, timeout=60) as response:
            source = response.read()
    if sha256(source) != recipe["source"]["sha256"]:
        raise SystemExit("Source hash mismatch: expected the exact pinned upstream file.")
    normalized = source.decode("utf-8")
    for old, new in recipe["transforms"]:
        normalized = normalized.replace(old, new)
    lines = normalized.splitlines(keepends=True)
    prepared = []
    for entry in recipe["outputs"]:
        pieces = []
        for part in entry["parts"]:
            if "copy_lines" in part:
                start, stop = part["copy_lines"]
                if not (0 <= start <= stop <= len(lines)):
                    raise SystemExit("Invalid source interval in recipe.")
                pieces.append("".join(lines[start:stop]))
            else:
                pieces.append(part["local_text"])
        output = "".join(pieces).encode("utf-8")
        if sha256(output) != entry["sha256"]:
            raise SystemExit(f"Generated hash mismatch: {entry['path']}")
        target = args.output_dir / entry["path"]
        if target.exists() and target.read_bytes() != output:
            raise SystemExit(f"Refusing to replace a changed file: {target}")
        if args.check and not target.exists():
            raise SystemExit(f"Missing generated file: {target}")
        prepared.append((target, output, entry["sha256"]))
    for target, output, digest in prepared:
        if not args.check and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as temporary:
                temporary.write(output)
                temporary_path = Path(temporary.name)
            temporary_path.replace(target)
        print(f"verified {target.name} sha256={digest}")


if __name__ == "__main__":
    main()
