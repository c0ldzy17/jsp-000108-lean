#!/usr/bin/env python3
"""Archive the current stage, excluding generated/restricted and build files.

This does not declare verification complete or publish anything externally.
"""
import argparse
import hashlib
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path,
                    default=root.with_name(root.name + ".zip"))
args = parser.parse_args()
excluded_dirs = {".git", ".lake", "__pycache__", "research", ".cache"}
excluded_files = {"Jsp108/Pruning.lean", "Jsp108/Geometry.lean"}
output = args.output.resolve()
if output.is_relative_to(root):
    raise SystemExit("Choose an archive path outside the staging directory.")
output.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if set(relative.parts) & excluded_dirs or str(relative) in excluded_files:
            continue
        if path.suffix in {".pyc", ".olean", ".ilean", ".o"}:
            continue
        info = zipfile.ZipInfo(str(relative), date_time=(2026, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes())
print(f"{output}\nsha256={hashlib.sha256(output.read_bytes()).hexdigest()}")
