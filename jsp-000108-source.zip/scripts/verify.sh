#!/bin/sh
# Run from the package root after obtaining the pinned dependencies.
set -eu
cd "$(dirname "$0")/.."
mkdir -p verification
python3 scripts/verify_source_hashes.py
lake env lean --version > verification/toolchain.txt
lake build Jsp108 > verification/lake-build.log 2>&1
lake env lean Jsp108/Main.lean > verification/axioms.txt 2>&1
python3 - <<'PY'
from pathlib import Path
import re
report = Path('verification/axioms.txt').read_text()
names = ['unit_distance_fixed_power', 'jsp_000108', 'jsp_000108_eventually']
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
for name in names:
    matches = re.findall(r"'Jsp108\." + name + r"' depends on axioms: \[([^\]]*)\]", report)
    if len(matches) != 1 or set(x.strip() for x in matches[0].split(',')) != allowed:
        raise SystemExit('Unexpected or absent axiom report: ' + name)
print('All three endpoints use exactly the standard three axioms.')
PY
lake env lean --run scripts/checkCanonicalAxioms.lean Jsp108.Main \
  > verification/canonical-axioms.txt 2>&1
lake env lean --run scripts/focusedFreshReplay.lean Jsp108.Main \
  Jsp108.unit_distance_fixed_power Jsp108.jsp_000108 Jsp108.jsp_000108_eventually \
  > verification/kernel-replay.txt 2>&1
lake env leanchecker -v Jsp108 > verification/leanchecker.txt 2>&1
printf '%s\n' 'Build, endpoint axiom checks, fresh dependency replay, and leanchecker passed.'
