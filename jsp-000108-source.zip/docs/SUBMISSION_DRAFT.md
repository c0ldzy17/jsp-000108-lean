# JSP-000108: full negative answer to the subpolynomial equidistance question

This adds an observation candidate for the full JSP-000108 / Erdős 92 question. The proof rules out every upper bound `f(n) ≤ n^(o(n))` with `o(n) → 0`, both for every cardinality and for all sufficiently large cardinalities. The exact endpoints are `Jsp108.jsp_000108` and `Jsp108.jsp_000108_eventually`.

The fixed-positive-exponent input combines Naganori Yamaguchi's unconditional Sawin tower formalization with the arithmetic and geometric components of Logical Intelligence's unit-distance development. The conditional hypotheses in the latter project's original Section3 are not assumed. Local work includes the split-prime and tower-to-geometry bridges, exact pair-count and extremal-attainment transfers, core-size strengthening, compatibility adaptations, and the asymptotic assembly. Original mathematics and reused formal proofs retain their attribution and source-specific license notices.

This addresses the full subpolynomial question. Related [PR 256](https://github.com/TheJustinSunPrize/awards/pull/256) proves a fixed-constant negative assertion involving `C / log log n` and explicitly excludes the separate weak `o(1)` variant. A live all-state search at **2026-09-17 10:39:53 UTC** found no other matching JSP-000108/Erdos92 issue or PR. This search does not establish global first priority.

Completed local checks:

- Lean **4.33.1**, Mathlib **`0df444a360eaa60ab8c11dca51a86af692955474`**; the complete project build passed with **10,329 jobs**.
- All three final endpoint reports list exactly **`propext`, `Classical.choice`, `Quot.sound`**.
- The stock Lean checker successfully replayed **all nine local modules**.
- A fresh stock-kernel replay checked the dependency closure of all three final endpoints: **132,794 declarations**, inserted into an **empty environment at trust level 0**. All three endpoints passed, and the only replayed axioms were the three listed above.
- The three imported axiom declarations were compared with the toolchain's canonical `Init` declarations; their declaration kinds, types, and universe parameters matched.
- The official candidate draft passed `manage.py validate`, `links`, `build`, and `check`; all **22 repository tests** passed.

These compiler and kernel checks are local reproducibility evidence. They are not independent third-party review or a second independently implemented kernel.

The external proof repository is [c0ldzy17/jsp-000108-lean](https://github.com/c0ldzy17/jsp-000108-lean). The exact source commit, release asset URL, SHA-256, byte count, and evidence URLs will be inserted after the source release is published. Large source and log artifacts remain outside the awards repository. The source package includes portable dependency pins, reproduction scripts, source hashes, theorem statements, and explicit treatment of the reconstructed plby adapters' unestablished license boundary.

The candidate is **under verification** with a null decision, null formal record, null independent review, and an unconfirmed recipient placeholder. A signed formal statement and designated independent verification are left to the repository's curatorial process. This is formal verification of known mathematics, submitted through GitHub account `c0ldzy17` using OpenAI Codex and cooperating agents; it does not claim original mathematical discovery, an award, recipient confirmation, or established first priority.
