# Prior art and race check

## English

Checked on 2026-09-17. These are scoped search findings, not a guarantee of world-wide priority.

1. [The official PR 256](https://github.com/TheJustinSunPrize/awards/pull/256), opened 2026-09-16, is titled “JSP-000108: fixed-constant negative theorem observation”. Its body explicitly targets the negation of `∃ C > 0, eventually f(n) ≤ n^(C/loglog n)`. Separate live official issue searches for the exact identifier `JSP-000108` and the alias `Erdos92` each returned one result, PR 256, with `incomplete_results=false`. Its last reported update was 2026-09-16T22:28:18Z. This is related prior formalization, not the full subpolynomial target.
2. [`plby/lean-proofs`, revision `8822f7ddef30fadbd92e1c6ab4ed897af356af5e`](https://github.com/plby/lean-proofs/blob/8822f7ddef30fadbd92e1c6ab4ed897af356af5e/src/latest/ErdosProblems/Erdos92.lean) proves the same fixed-constant negative result. Its graph-pruning and equidistance definitions are relevant prior work and must be attributed if reused.
3. [`Erdos90b`](https://github.com/plby/lean-proofs/blob/8822f7ddef30fadbd92e1c6ab4ed897af356af5e/src/latest/ErdosProblems/Erdos90b.lean) exposes Alpöge's arbitrary-constant unit-distance lower bound. This is not a fixed-polynomial lower bound. Its vendored source is from [Kim Morrison's unit-distance project](https://github.com/kim-em/erdos-unit-distance).
4. [Formal Conjectures, Erdős 92](https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/92.lean) contains a `sorry` in the inspected weak statement. A formal statement carrying `research solved` is not a Lean proof.
5. [Formal Conjectures, Erdős 90](https://github.com/google-deepmind/formal-conjectures/blob/main/FormalConjectures/ErdosProblems/90.lean) records the fixed-polynomial theorem and the Sawin reduction challenges. Its link to a totally-real-tower formalization concerns an arithmetic component; that link by itself does not establish the entire polynomial unit-distance theorem.

These official searches are narrower than searching every possible alias and external repository. A final duplicate search must include the weak/subpolynomial statement, Erdős 90's fixed-polynomial variant, and newly published sources immediately before submission. No earlier complete weak proof has been established by this check; no unconditional absence claim is made.
