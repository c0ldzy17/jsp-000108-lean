# Official record and submission conventions

## English

Reviewed against official repository revision `f4e7173d89dfe91022a185427d63452c8ffbf6ae`.

- [Contributing](https://github.com/TheJustinSunPrize/awards/blob/f4e7173d89dfe91022a185427d63452c8ffbf6ae/CONTRIBUTING.md): use English, cite evidence, disclose relevant contributions and conflicts, retain third-party attribution and licenses, and link related issues. Passing repository checks does not announce an award.
- [Formal verification](https://github.com/TheJustinSunPrize/awards/blob/f4e7173d89dfe91022a185427d63452c8ffbf6ae/docs/verification.md): connect the original problem, formal statement, pinned proof, reproduction evidence and review conclusion. CI checks records rather than mathematical truth. A source link or local build is not a completed independent verification record.
- [Record guide](https://github.com/TheJustinSunPrize/awards/blob/f4e7173d89dfe91022a185427d63452c8ffbf6ae/docs/records.md): candidates and announced awards remain separate; candidate decisions are null. Unconfirmed recipients use placeholders. Formal evidence needs a versioned statement and appropriate verification metadata. Large artifacts belong in external archives with identifiers, hashes and byte counts.

The public problem-bank flags do not themselves create a nomination or guarantee first-verification eligibility. This package must describe the exact stronger statement relative to PR 256 and distinguish new formal work from reused proofs. No package document should state an award level, payment entitlement, acceptance, independent verification, or confirmed first priority without the corresponding published evidence.

The repository's current contribution mechanism and templates are authoritative for the eventual PR. This working documentation does not create a candidate record or make a public submission.
