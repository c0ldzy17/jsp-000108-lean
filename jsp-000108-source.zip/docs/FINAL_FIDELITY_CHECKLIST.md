# JSP-000108 statement and completion audit

The complete proof build passed with 10,329 jobs. This document separates the source-level statement audit, completed kernel checks, and remaining packaging/submission checks.

## Reference statements

The pinned [JSP-000108 catalog entry](https://github.com/TheJustinSunPrize/awards/blob/f4e7173d89dfe91022a185427d63452c8ffbf6ae/problems/catalog-0101-0200.md#JSP-000108) asks whether the maximal equidistance count guaranteed at every point can be smaller than every fixed positive power of the number of points. The catalog's recorded status is `Solved`, `Lean proof: No`, and `Eligible to claim: No`; it is not itself an award promise.

The precise comparison is the [Formal Conjectures weak variant](https://github.com/google-deepmind/formal-conjectures/blob/40e7c98697de6f66b8cbdbf641749ab39ed9c152/FormalConjectures/ErdosProblems/92.lean):

```text
¬ ∃ o : ℕ → ℝ, o =o[atTop] (1 : ℕ → ℝ) ∧
    ∀ n, (Erdos92.f n : ℝ) ≤ (n : ℝ) ^ (o n)
```

Its source uses `answer(False) ↔ ...`; the negative proposition above has exactly that mathematical content. The canonical file still contains `sorry` at this endpoint, so it is used as a statement reference, not imported as a proof.

## Predicate checks completed from source

| Check | Local implementation and result |
|---|---|
| Euclidean plane | `EuclideanSpace ℝ (Fin 2)`; canonical scoped `ℝ²` expands to this same type in `FormalConjecturesForMathlib/Geometry/2d.lean`. |
| Distinct finite points | A `Finset` of planar points has no multiplicities. |
| Other points only | `maxEquidistantPointsAt` first erases the center. A neighbor of a retained center is distinct and hence has positive Euclidean distance. |
| Radius may depend on center | Each center has its own image of distances and its own maximum; there is no global-radius requirement in the target. |
| Extremal quantifiers | `possible_f_values n` asks for an existing set of exactly `n` points, nonempty, with the bound at every center. `f n` is the supremum over achievable `k`. This agrees with the canonical definitions. |
| Finite supremum | `possible_f_values_BddAbove` proves every possible value is at most `n`; the local proof does not assume a nonexistent infinite maximum. |
| Unit-distance special case | `unitGraph` connects exactly pairs at distance one. A lower bound obtained from this special case is valid for the unrestricted per-center radius in the target. |
| Ordered versus unordered pairs | `two_mul_unitDist` and `card_edgeFinset_unitGraph` account for the factor two. `CountTransport.li_count_eq_unitDist` identifies LI's `Sym2` count with this same unordered count. |
| Supremum attained | `CountTransport.li_count_attained` supplies an actual finite configuration from a positive LI extremal count; it proves the possible-count set finite and nonempty. |
| Fixed exponent | `PolynomialUnitDistanceGrowth` quantifies one `δ > 0` before every cardinality threshold. It is not the weaker arbitrary-constant `C / log log n` input. |
| Strict inequality | The LI non-strict exponent bound becomes a strict bound by replacing `δ` with `δ / 2` and choosing `n > 1`. |
| Core size | The pruning transfer gives `k ≤ m ≤ n` and `k ≤ f m`. This prevents bounded-size cores from masquerading as an asymptotic counterexample. |
| Asymptotic conclusion | `Asymptotic.lean` disproves even an eventual subpolynomial bound. Its all-`n` corollary therefore matches the canonical negative target without relying on special conventions at `n = 0` or `n = 1`. |

The eventual version is useful because it cannot succeed merely by exploiting a small exceptional cardinality. Its proof chooses `k = floor(n^(δ/2)) + 1` after both asymptotic thresholds and forces `m` above those thresholds.

## Completed proof checks

| Check | Result and evidence |
|---|---|
| Unconditional final input | `Main.lean` instantiates `PolynomialUnitDistanceGrowth` using `exists_split_tower` and `ErdosUnitDistance.polynomial_of_totally_real_split_fields`; the final endpoints have no mathematical hypotheses. |
| Conditional LI inputs removed | The final theorem types contain neither `Hyp_GolodShafarevichInequality` nor `Hyp_ShafarevichRelationRankBound`. The unconditional Sawin tower supplies the number-field input. |
| Complete actual build | Passed using Lean 4.33.1 and the pinned dependencies: `verification/lake-build.log` ends `Build completed successfully (10329 jobs).` |
| Final endpoint axioms | All three final endpoints report exactly `propext`, `Classical.choice`, and `Quot.sound`; see `verification/axioms.txt`. These are final theorem reports, not just component audits. |
| Tower endpoint axioms | The unconditional Sawin endpoint and the three local splitting/tower adapters report the same three axioms; see `verification/tower-axioms.txt`. |
| Stock Lean checker | Replay of the local `Jsp108` modules passed; see `verification/leanchecker.txt`. Imported dependencies in this check are distinguished from the fresh replay below. |
| Fresh final dependency replay | Passed for all three final endpoints: 132,794 declarations replayed into an empty trust-level-zero environment, with constructor/recursor checks and only the three standard axioms. See `verification/kernel-replay.txt`. |
| Canonical axiom types | Passed: all three permitted axioms have the same types and universe parameters as `Init` loaded directly from the pinned Lean toolchain. See `verification/canonical-axioms.txt`. |
| Extracted-file preparation | The pinned-source recipe reproduced both expected output hashes and passed its existing-file check; see `REPRODUCIBLE_PACKAGING.md`. |

## Remaining packaging and submission checks

1. **Publishable-package reconstruction:** the proof build and preparation recipe have passed separately. A complete build from a separately reconstructed archive is not yet recorded. The unestablished license boundary for the extracted plby proof code remains documented explicitly.
2. **Official submission review:** recheck the live official race before submission. Existing PR 256 addresses the fixed-constant bound; that fact alone does not establish priority for the complete weak result.

The ordinary build, stock checker, and focused fresh replay all use Lean's own kernel. No independently implemented external checker is claimed. No external submission, verified priority, or award eligibility is asserted by this checklist.
