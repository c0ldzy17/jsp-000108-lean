# JSP-000108 statement and completion audit

This checklist concerns the v1.1 source revision. The statement and source review below has been completed. Final package verification is recorded separately: see the final reports and `SOURCE_MANIFEST.json` for the tested sources and run results. Checks of the earlier v1.0 proof package do not establish verification of the changed v1.1 sources.

## Reference statements

The pinned [JSP-000108 catalog entry](https://github.com/TheJustinSunPrize/awards/blob/f4e7173d89dfe91022a185427d63452c8ffbf6ae/problems/catalog-0101-0200.md#JSP-000108) asks whether the maximal equidistance count guaranteed at every point can be smaller than every fixed positive power of the number of points. The catalog's recorded status is `Solved`, `Lean proof: No`, and `Eligible to claim: No`; it is not itself an award promise.

The precise comparison is the [Formal Conjectures weak variant](https://github.com/google-deepmind/formal-conjectures/blob/40e7c98697de6f66b8cbdbf641749ab39ed9c152/FormalConjectures/ErdosProblems/92.lean):

```text
¬ ∃ o : ℕ → ℝ, o =o[atTop] (1 : ℕ → ℝ) ∧
    ∀ n, (Erdos92.f n : ℝ) ≤ (n : ℝ) ^ (o n)
```

Its source uses `answer(False) ↔ ...`; the negative proposition above has exactly that mathematical content. The pinned canonical file contains `sorry` at this endpoint, so it is used as a statement reference, not imported as a proof.

## Predicate checks completed from source

| Check | Local implementation and result |
|---|---|
| Euclidean plane | `EuclideanSpace ℝ (Fin 2)`; canonical scoped `ℝ²` expands to this same type in `FormalConjecturesForMathlib/Geometry/2d.lean`. |
| Exact canonical definitions | Source comparison passed for the bodies of `maxEquidistantPointsAt`, `hasMinEquidistantProperty`, `possible_f_values`, and `f`, after expanding the plane notation and normalizing whitespace. The same types and operations are retained. |
| Distinct finite points | A `Finset` of planar points has no multiplicities. |
| Other points only | `maxEquidistantPointsAt` first erases the center. A neighbor of a retained center is distinct and hence has positive Euclidean distance. |
| Radius may depend on center | Each center has its own image of distances and its own maximum; there is no global-radius requirement in the target. |
| Extremal quantifiers | `possible_f_values n` asks for an existing set of exactly `n` points, nonempty, with the bound at every center. `f n` is the supremum over achievable `k`. This agrees with the canonical definitions. |
| Finite supremum | `possible_f_values_BddAbove` proves every possible value is at most `n`; the local proof does not assume a nonexistent infinite maximum. |
| Unit-distance special case | `unitGraph` connects exactly pairs at distance one. A lower bound obtained from this special case is valid for the unrestricted per-center radius in the target. |
| Ordered versus unordered pairs | `two_mul_unitDist` and `card_edgeFinset_unitGraph` account for the factor two. `CountTransport.li_count_eq_unitDist` identifies LI's `Sym2` count with this same unordered count. |
| Supremum attained | `CountTransport.li_count_attained` supplies an actual finite configuration from a positive LI extremal count; it proves the possible-count set finite and nonempty. |
| Fixed exponent | `PolynomialUnitDistanceGrowth` quantifies one `δ > 0` before every cardinality threshold. It is not the weaker arbitrary-constant `C / log log n` input. |
| Strict inequality | The LI non-strict exponent bound becomes a strict bound by replacing `δ` with `δ / 2` and choosing `n > 1`. |
| Core size | The pruning transfer gives `k ≤ m ≤ n` and `k ≤ f m`. This prevents bounded-size cores from masquerading as an asymptotic counterexample. |
| Asymptotic conclusion | `Asymptotic.lean` disproves even an eventual subpolynomial bound. Its all-`n` corollary therefore matches the canonical negative target without relying on special conventions at `n = 0` or `n = 1`. |

The eventual version is useful because it cannot succeed merely by exploiting a small exceptional cardinality. Its proof chooses `k = floor(n^(δ/2)) + 1` after both asymptotic thresholds and forces `m` above those thresholds.

## v1.1 source architecture reviewed

| Component | Source review result |
|---|---|
| Pruning | The new proof maximizes the integer surplus `edgeCount G t - k * t.card` over subsets. Positive surplus excludes the empty set; partitioning edges at a vertex and maximality give the required minimum degree. This replaces the earlier deletion-induction implementation. |
| Geometry | Ordered-edge counting uses an embedding of the whole product and filtering. The neighbor bound uses an injective map into a circle fiber, with the empty fiber handled separately. The proof retains the required graph-count and extremal-function interfaces. |
| Canonical content | The invariant definitions and `possible_f_values_BddAbove` are reused from the explicitly Apache-2.0-licensed Formal Conjectures source. They are distinct from the newly implemented geometry proofs. |
| Downstream contracts | The statements required by `CountTransport.lean`, `Reduction.lean`, and `Main.lean` retain the same hypotheses and conclusions. In particular, the transfer yields a nonempty subset of the original configuration and a genuine lower bound on its canonical `f`. |
| No added proof assumptions | Source review of the replacement files found no `sorry`, `admit`, new `axiom`, `native_decide`, `unsafe`, `extern`, or `implemented_by`. This source scan is separate from the final endpoint axiom reports and kernel checks below. |
| Original additions and third-party scope | Original additions and local modifications are released under Apache-2.0. `LICENSE_SCOPE.md`, `LICENSES/README.md`, and `ATTRIBUTION.md` preserve the separate Formal Conjectures, Kim Morrison, LI, and Sawin provenance and notices. |

Version v1.0 used copied or adapted plby proof blocks and a pinned-source reconstruction procedure. The v1.1 revision replaces those adapters with the proofs described above. The prior work remains credited; the replacement does not claim new underlying mathematics, legal clean-room development, or a retroactive license for the old copied blocks. Current reproduction uses the v1.1 sources and manifest, not the earlier extraction procedure.

## Final input and verification evidence

| Check | Result and evidence |
|---|---|
| Unconditional final input | `Main.lean` instantiates `PolynomialUnitDistanceGrowth` using `exists_split_tower` and `ErdosUnitDistance.polynomial_of_totally_real_split_fields`; the final endpoints have no mathematical hypotheses. |
| Conditional LI inputs removed | The final theorem types contain neither `Hyp_GolodShafarevichInequality` nor `Hyp_ShafarevichRelationRankBound`. The unconditional Sawin tower supplies the number-field input. |
| Complete package build | See the final build report and manifest for the v1.1 source revision, pinned Lean 4.33.1 dependencies, and actual outcome. This checklist does not mark the running final verification complete. |
| Final endpoint axioms | See the final endpoint reports for `unit_distance_fixed_power`, `jsp_000108`, and `jsp_000108_eventually`. The permitted set is `propext`, `Classical.choice`, and `Quot.sound`; component audits alone do not establish the final reports. |
| Tower endpoint axioms | See the final evidence for the unconditional Sawin endpoint and the local splitting/tower adapters. |
| Stock Lean checker | See the final local-module replay report. Imported dependencies in this check are distinguished from fresh dependency replay. |
| Fresh final dependency replay | See the final replay report for the actual checked roots, dependency closure, empty trust-level-zero environment, permitted axioms, and outcome. No old declaration count is carried forward as a v1.1 result. |
| Canonical axiom types | See the final report comparing the permitted axioms' types and universe parameters with `Init` loaded directly from the pinned Lean toolchain. |
| Source correspondence and reproduction | See `SOURCE_MANIFEST.json`, the final source-hash report, and `REPRODUCIBLE_PACKAGING.md` for the exact distributed sources and clean package reproduction procedure. |

## Package and official review status

1. **Final package verification:** consult the final reports and manifest for the completed run results. A source review, a previous-version build, and a clean build of the distributed v1.1 package are distinct evidence.
2. **Official submission review:** the existing [PR 665](https://github.com/TheJustinSunPrize/awards/pull/665) is open and official review remains pending. This source checklist does not claim designated independent verification, a merged record, or accepted eligibility. Earlier PR 256 addresses the fixed-constant bound; that fact alone does not establish priority for the complete weak result.

The ordinary build, stock checker, and focused fresh replay all use Lean's own kernel. No independently implemented external checker is claimed. Submission is distinct from official verification, established first priority, and an award decision.
