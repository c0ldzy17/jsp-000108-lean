# Statement fidelity

## English

The [official catalogue](https://github.com/TheJustinSunPrize/awards/blob/f4e7173d89dfe91022a185427d63452c8ffbf6ae/problems/catalog-0101-0200.md#JSP-000108) asks whether the equidistant-neighbor count can be smaller than every fixed positive power of the number of points. The corresponding [Erdős 92 statement](https://www.erdosproblems.com/92) has two different bounds.

| Proposition | Meaning | Scope |
|---|---|---|
| `∃ o, o(n) → 0 ∧ eventually f(n) ≤ n^(o(n))` | Some subpolynomial upper bound exists. | Main target here. |
| `∃ C > 0, eventually f(n) ≤ n^(C / log log n)` | A particular, smaller family of subpolynomial bounds suffices. | Refuted by the existing plby source and PR 256. |

The second assertion implies the first. Its negation therefore does **not** imply the negation of the first. For example, an exponent `1 / sqrt(log log n)` still tends to zero while eventually exceeding `C / log log n` for every fixed `C`. Merely beating every fixed `C / log log n` exponent cannot establish the requested result.

## Necessary geometric definitions

The model must use finite subsets of the Euclidean plane, ordinary Euclidean distance, distinct neighbors, and a radius allowed to depend on the center. The maximum over configurations and the minimum over centers must have the intended order. A unit-distance construction is a valid special case because it uses the same positive radius at every vertex.

The canonical Formal Conjectures weak variant uses an all-`n` bound. Refuting the eventual version is stronger and immediately refutes that formulation. Small-cardinality conventions must be documented when identifying the two positive formulations; they are not needed for this negative implication.

## Mathematical input and planned transfer

[Sawin's published abstract](https://arxiv.org/abs/2605.20579) gives arbitrarily large planar configurations with more than `n^1.014` unit-distance pairs. Thus a fixed positive exponent is available mathematically. The current formalization task must provide a proved Lean input of the form

```text
∃ ε > 0, ∀ N, ∃ P, N ≤ |P| ∧ |P|^(1+ε) < unitDistancePairs(P).
```

A finite graph with more than `k * |V|` edges has a nonempty induced subgraph of minimum degree at least `k`, by repeatedly deleting lower-degree vertices. Applied to the unit-distance graph with a suitable power-sized `k`, this gives sets whose minimum equidistance count has a fixed positive power lower bound. Their sizes must also be proved unbounded; a minimum-degree lower bound bounds the surviving cardinality below. This is the geometric/combinatorial transfer, not a substitute for the fixed-polynomial input.

The theorem [`Erdos90b.not_erdos_90`](https://github.com/plby/lean-proofs/blob/8822f7ddef30fadbd92e1c6ab4ed897af356af5e/src/latest/ErdosProblems/Erdos90b.lean) instead quantifies `C` before counterexamples to `n^(1+C/loglog n)`. It does not contain a fixed positive `ε`, and cannot be used as though it did.

## Completion criterion

The final theorem must refute the first row above without an unproved polynomial-growth hypothesis. Its proof and imported dependencies must be checked with the pinned toolchain, and its actual axiom dependencies recorded. A conditional transfer theorem is useful development work but is not the completed target.
