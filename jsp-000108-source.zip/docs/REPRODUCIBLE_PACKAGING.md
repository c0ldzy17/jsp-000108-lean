# Reproducible source preparation and license boundaries

## Pinned-source findings

The checked plby revision is `8822f7ddef30fadbd92e1c6ab4ed897af356af5e`.
Its [`src/latest/LICENSE`](https://github.com/plby/lean-proofs/blob/8822f7ddef30fadbd92e1c6ab4ed897af356af5e/src/latest/LICENSE) says that **some external files** are Apache-2.0. It does not identify every file as Apache-2.0.
The [`Erdos92.lean` header](https://github.com/plby/lean-proofs/blob/8822f7ddef30fadbd92e1c6ab4ed897af356af5e/src/latest/ErdosProblems/Erdos92.lean) credits L. Alpöge, the Formal Conjectures authors, and Codex / GPT-5.6 Sol, but includes no express license grant for the new proofs. No additional grant was found in the root README or the problem's Markdown page. A blanket Apache claim for this file has therefore not been established.

The canonical definitions have a distinct, explicit source: [`FormalConjectures/ErdosProblems/92.lean`](https://github.com/google-deepmind/formal-conjectures/blob/40e7c98697de6f66b8cbdbf641749ab39ed9c152/FormalConjectures/ErdosProblems/92.lean) carries Copyright 2025 The Formal Conjectures Authors and an Apache-2.0 notice. That notice covers those upstream definitions; it does not extend a license to separate plby proofs.

GitHub distinguishes public viewing/forking from an open-source license. See its [repository licensing documentation](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository). The procedure below is a reproducibility mechanism, not an additional license grant or a conclusion that every derivative patch may be redistributed.

## Concrete preparation procedure

For an archive that avoids embedding the two extracted proof files, include:

- `scripts/prepare_pruning_geometry.py`;
- `scripts/pruning-geometry-recipe.json`;
- the original local modules, the explicitly licensed dependencies and their notices, and these provenance documents.

Exclude `Jsp108/Pruning.lean` and `Jsp108/Geometry.lean` from that archive. Also exclude `.lake`, source caches, downloaded plby files, and build artifacts. The recipe embeds references to upstream line intervals and local additions; it does not embed the copied upstream proof blocks. The only normalization before extraction is replacing the plane notation `ℝ²` by its explicit type `EuclideanSpace ℝ (Fin 2)`.

Run preparation before any Lean build:

```sh
python3 scripts/prepare_pruning_geometry.py
lake build
```

The script fetches exactly the pinned raw source, verifies its SHA-256, applies the deterministic recipe, and checks both output hashes. It refuses to overwrite a changed existing file. Reviewers can instead use a source they obtained independently:

```sh
python3 scripts/prepare_pruning_geometry.py --source /path/to/Erdos92.lean
python3 scripts/prepare_pruning_geometry.py --source /path/to/Erdos92.lean --check
```

The `--output-dir` option supports reconstruction in a separate directory. Existing project files were not modified during preparation testing.

| File | SHA-256 |
|---|---|
| Pinned upstream `Erdos92.lean` | `f87842ac1e3d6641d6bdc376b8c74b3380b34ceb36e27eb68285dadc1230238d` |
| Generated `Jsp108/Pruning.lean` | `01e13d5f444631e163ab646d837ded9ffc29b4efd6e98686bf087f5970d0c8d5` |
| Generated `Jsp108/Geometry.lean` | `8651de0d162557acaa1d0d62b6bfea3ebb4d5c82abbdd95417e4bb4b76982b33` |

Both the existing-file check and reconstruction into an empty temporary directory passed. If either proof file changes, the recipe and expected hashes must be regenerated and retested before packaging. Do not apply an umbrella Apache notice to material whose license remains unestablished.

## Other reused sources

The explicit Apache-2.0 notices and licenses for Kim Morrison's unit-distance counting code, Logical Intelligence's arithmetic/geometric development, and Naganori Yamaguchi's Sawin tower development must accompany any copied portions. See `ATTRIBUTION.md` for the exact pins and scope of reuse.

## Recorded verification and source changes

The actual assembled proof build passed with 10,329 jobs using the pinned Lean 4.33.1 toolchain. All three final endpoints report exactly `propext`, `Classical.choice`, and `Quot.sound`, and stock `leanchecker` replay of the local modules passed. The corresponding reports are under `verification/`. Fresh replay of all three final endpoints also passed: 132,794 declarations were checked in an empty trust-level-zero environment with only the three standard axioms. The canonical-axiom comparison also passed: all three permitted axioms match the types and universe parameters in the pinned toolchain's `Init`. These checks use Lean's own kernel, not an independently implemented external checker.

The package contains 12 Logical Intelligence component modules, including the local compatibility adaptations and tower bridge described in `vendor/li/PATCHES.md`. It contains 1,600 Sawin tower modules with one source-level resource-setting adaptation: `set_option maxHeartbeats 0 in` on `rationalCyclotomicTorsionFixedFieldGalEquivZHat_restrictNormal` in `Lean4/ClassFieldTheory/GlobalClassFieldTheory/Reciprocity/CyclotomicTorsionFixedField.lean`. This removes the deterministic heartbeat limit for that declaration; it does not change its statement, proof body, or the kernel's logical checks. The adapted file's hash is recorded in `SOURCE_MANIFEST.json`.

The successful build was performed in the assembled working project. The deterministic preparation recipe was tested separately. A complete build from a fresh reconstruction of the distributable archive is not yet recorded. After preparation, `sh scripts/verify.sh` runs the package's full verification sequence and writes fresh reports; the documentation must be updated only from those actual results.
